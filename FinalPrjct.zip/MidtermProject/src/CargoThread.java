import java.util.*;

class CargoThread extends Thread {
    private final List<Cargo> cargoChunk;
    private final Map<Integer, List<Cargo>> localGroupedByLocation;

    public CargoThread(List<Cargo> cargoChunk) {
        this.cargoChunk = cargoChunk;
        this.localGroupedByLocation = new HashMap<>();
    }

    @Override
    public void run() {
        for (Cargo cargo : cargoChunk) {
            localGroupedByLocation
                    .computeIfAbsent(cargo.location, k -> new ArrayList<>())
                    .add(cargo);
        }
    }

    public Map<Integer, List<Cargo>> getResult() {
        return localGroupedByLocation;
    }
}

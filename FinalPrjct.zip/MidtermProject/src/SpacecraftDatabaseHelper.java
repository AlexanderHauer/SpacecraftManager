import java.sql.*;

public class SpacecraftDatabaseHelper {

    public static void insertSpacecraftData(Connection conn, Spacecraft spacecraft) throws SQLException {
        String query = "INSERT INTO Spacecraft (ship_type, length) VALUES (?, ?)";

        PreparedStatement stmt = conn.prepareStatement(query);

        stmt.setString(1, spacecraft.shipType);
        stmt.setInt(2, spacecraft.length);
        stmt.executeUpdate();
        stmt.close();
    }

}


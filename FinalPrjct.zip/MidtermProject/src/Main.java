import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) throws SQLException {

        try {

            Connection conn = DatabaseConnection.getConnection();
            DatabaseUtils.setConnection(conn);
            System.out.println("Connected to the database successfully.");

            Scanner scanner = new Scanner(System.in);
//-------------------------------------------------------------------------------------- creating environment
            Spacecraft spacecraft = new Spacecraft("Planet Cracker", 1600);
            ArrayList<Crew> crewList = new ArrayList<>();
            ArrayList<Cargo> cargoList = new ArrayList<>();
            ArrayList<Bridge> bridgeList = new ArrayList<>();
            ArrayList<String> IDlist = new ArrayList<>();
            ArrayList<String> superIDlist = new ArrayList<>();
            Spaceship spaceship;

            //check program argument
            if (args.length == 1 && args[0].equalsIgnoreCase("load")) {
                spaceship = loadSpaceshipData();
                if (spaceship == null) {
                    System.out.println("Failed to load saved data. Starting fresh.");
                    spaceship = new Spaceship("USG Ishimura", spacecraft, crewList, cargoList, bridgeList, IDlist, superIDlist, 2008);
                } else {
                    System.out.println("Loaded saved data successfully.");
                }
            } else {
                // no argument
                System.out.print("Would you like to load a saved file or start fresh? (type 'load' or 'fresh'): ");
                String choice = scanner.nextLine().trim().toLowerCase();

                if(choice.equals("fresh")) {
                    spaceship = new Spaceship("USG Ishimura", spacecraft, crewList, cargoList, bridgeList, IDlist, superIDlist, 2008);

                    SpacecraftDatabaseHelper.insertSpacecraftData(conn, spacecraft);

                    SpaceshipDatabaseHelper.insertSpaceshipData(conn, spaceship, 7);
                }
                else {
                    spaceship = loadSpaceshipData();
                    if (spaceship == null) {
                        System.out.println("Failed to load saved data. Starting fresh.");
                        spaceship = new Spaceship("USG Ishimura", spacecraft, crewList, cargoList, bridgeList, IDlist, superIDlist, 2008);
                    }
                }
            }


//-------------------------------------------------------------------------------------- login
            int user_clearance = 3;
            boolean on = true;

            while(on) {
                System.out.println("Login as:\n1. Bridge member\n2. Crew member\n3. Visitor\n");
                int resp = scanner.nextInt();
                scanner.nextLine();
                String id;
                boolean found = false;

                switch (resp) {

                    case 1:
                        System.out.println("Please enter your Bridge ID card number: ");
                        id = scanner.nextLine();
                        for (String ids : spaceship.superIDlist) {
                            if (ids.equals(id))
                                found = true;
                        }
                        if (id.equals("0001") || found) { // Check for emergency code or presence in superIDlist
                            System.out.println("Welcome \n");
                            user_clearance = 1;
                            on = false;
                        } else {
                            System.out.println("Incorrect ID\n");
                        }
                        break;

                    case 2:
                        System.out.println("Please enter your Crew ID card number: ");
                        id = scanner.nextLine();
                        for (String ids : spaceship.IDlist) {
                            if (ids.equals(id))
                                found = true;
                        }
                        if (id.equals("0456") || found) { // Check for emergency code or presence in IDlist
                            System.out.println("Welcome... Please hurry to your work station and await further orders...\n");
                            user_clearance = 2;
                            on = false;
                        } else {
                            System.out.println("Incorrect crew ID\n");
                        }
                        break;

                    case 3:
                        System.out.println("Welcome visitor");
                        on = false;
                        break;

                    default:
                        System.out.println("Invalid response\n");
                }

            }

            while (true) {
                    System.out.println(" ------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("|                                                 <-> Available commands <->                                                         |");
                    System.out.println("|                                                    ````````````````````                                                            |");
                if(user_clearance == 1) {
                    System.out.println("|                    Crew  : addcrew [name], promote [name], addbridge [name], tosleep [name], towork[name]                          |");
                    System.out.println("|                    Db    : customquery                                                                                             |");
                }
                if(user_clearance <3) {
                    System.out.println("|                    Cargo : addcargo [name], movecargo [name], retrievecargo [name]                                                 |");
                    System.out.println("|                    Sort  : sortcrew, sortcargo                                                                                     |");
                    System.out.println("|                    Group : groupcrew, groupcargo                                                                                   |");
                }
                    System.out.println("|                    Info  : displaycrew, displaybridge, displaycargo, shipinfo                                                      |");
                    System.out.println(" ------------------------------------------------------------------------------------------------------------------------------------");

                System.out.println("\nEnter command: ");

                String command = scanner.nextLine();
                String[] commandParts = command.split(" ");

                if (commandParts[0].equalsIgnoreCase("exit")) {
                    System.out.println("Bye");
                    break;
                }

                switch (commandParts[0].toLowerCase()) {
//------------------------------------------------------------------------------------------- crew management
                    case "addcrew":

                        if(user_clearance==1) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a crew member name.");
                            } else {
                                spaceship.addCrew(commandParts[1]);
                            }
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;

                    case "addbridge":
                        if(user_clearance==1) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a bridge member name.");
                            } else {
                                spaceship.addBridge(commandParts[1]);
                            }
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;

                    case "promote":
                        if(user_clearance==1) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a crew member name.");
                            } else {
                                boolean found = false;
                                for (Crew crew : spaceship.crewList) {
                                    if (crew.crewName.equals(commandParts[1])) {
                                        try {
                                            crew.promote(crew);
                                        } catch (InvalidOperationException e) {
                                            System.out.println(e.getMessage());
                                        }
                                        found = true;
                                        break;
                                    }
                                }
                                if (!found) {
                                    System.out.println("Crew member " + commandParts[1] + " not found.");
                                }
                            }
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;


                    case "towork":
                        if(user_clearance==1) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a crew member name.");
                            } else {
                                boolean found = false;
                                for (Crew crew : spaceship.crewList) {
                                    if (crew.crewName.equals(commandParts[1])) {
                                        crew.crewWork();
                                        System.out.println("Crew member " + crew.crewName + " has been sent back to work.");
                                        found = true;
                                        break;
                                    }
                                }
                                if (!found)
                                    System.out.println("Crew member " + commandParts[1] + " not found.");
                            }
                        }
                        else
                            System.out.println("You are not authorized to complete this action");

                        break;

                    case "tosleep":
                        if(user_clearance==1) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a crew member name.");
                            } else {
                                boolean found = false;
                                for (Crew crew : spaceship.crewList) {
                                    if (crew.crewName.equals(commandParts[1])) {
                                        crew.crewSleep();
                                        System.out.println("Crew member " + crew.crewName + " is now on a short break.");
                                        found = true;
                                        break;
                                    }
                                }
                                if (!found)
                                    System.out.println("Crew member " + commandParts[1] + " not found.");
                            }
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;
//------------------------------------------------------------------------------------------- cargo management
                    case "addcargo":
                        if(user_clearance<3) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a cargo name.");
                            } else {
                                spaceship.addCargo(commandParts[1]);
                            }

                        }
                        else
                            System.out.println("You are not authorized to complete this action");

                        break;


                    case "retrievecargo":
                        if(user_clearance<3) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a cargo name.");
                            } else {
                                boolean found = false;
                                for (Cargo cargo : spaceship.cargoList) {
                                    if (cargo.name.equals(commandParts[1])) {
                                        System.out.println("Please provide quantity(volume): ");
                                        double vol = scanner.nextDouble();
                                        if(vol <= cargo.volume) {
                                            cargo.retrieveCargo(vol);
                                            System.out.println("Cargo retrieved.");
                                        }
                                        else
                                            System.out.println("Not enough cargo to complete command!\nCurrent cargo: " + cargo.name + " has a volume of " + cargo.volume);

                                        found = true;
                                        break;
                                    }
                                }
                                if (!found) {
                                    System.out.println("Cargo " + commandParts[1] + " not found.");
                                }
                            }
                        }
                        else
                            System.out.println("You are not authorized to complete this action");

                        break;

                    case "movecargo":
                        if(user_clearance<3) {
                            if (commandParts.length < 2) {
                                System.out.println("Please provide a cargo name.");
                            } else {
                                boolean found = false;
                                for (Cargo cargo : spaceship.cargoList) {
                                    if (cargo.name.equals(commandParts[1])) {
                                        System.out.println("Please provide location: ");
                                        int loc = scanner.nextInt();
                                        scanner.nextLine();
                                        if(loc >=1 && loc <=9) {
                                            cargo.moveCargo(loc);
                                            System.out.println("Cargo moved.");
                                        }
                                        else
                                            System.out.println("Invalid location!\nBays are number 1 through 9.");

                                        found = true;
                                        break;
                                    }
                                }
                                if (!found) {
                                    System.out.println("Cargo " + commandParts[1] + " not found.");
                                }
                            }

                        }
                        else
                            System.out.println("You are not authorized to complete this action");

                        break;
//------------------------------------------------------------------------------------------- sorting
                    case "sortcrew":
                        if(user_clearance<3) {
                            spaceship.sortCrewByRankAndAge();
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;

                    case "sortcargo":
                        if(user_clearance<3) {
                            spaceship.sortCargoByWeightAndVolume();
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;
//------------------------------------------------------------------------------------------- grouping
                    case "groupcrew":
                        if(user_clearance<3) {
                            spaceship.groupCrewByJob();
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;

                    case "groupcargo":
                        if(user_clearance<3) {
                            spaceship.groupCargoByLocation();
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;
//------------------------------------------------------------------------------------------- information
                    case "displaycrew":
                        spaceship.displayCrew();
                        break;

                    case "displaybridge":
                        spaceship.displayBridge();
                        break;

                    case "displaycargo":
                        spaceship.displayCargo();
                        break;

                    case "shipinfo":
                        spaceship.shipInfo();
                        break;
//-------------------------------------------------------------------------------------------- database management

                    case "customquery":
                        if(user_clearance==1) {
                            System.out.println("Enter custom query:\n");
                            String query = scanner.nextLine();
                            queryDatabase(conn, query);
                        }
                        else
                            System.out.println("You are not authorized to complete this action");
                        break;

                    default:
                        System.out.println("Unknown command: " + commandParts[0]);
                        break;
                }
                //screen clearing
                System.out.println("Press any key to get back to menu.");
                scanner.nextLine();
                System.out.print("\033[H\033[2J");
                System.out.flush();

            }
/*
            System.out.println("\n" +
                    "\n" +
                    "@**@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n" +
                    "****##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n" +
                    "%*%==@**@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n" +
                    "@*%++++=*%@@@@@@@@@@@@@@@@@@@@@@@@@@\n" +
                    "@%++****+**@@@@@@@@@@@@@@@@@@@@@@@@@\n" +
                    "@@*#+*%%#*+##@@@@@@@@@@@@@@@@@@@@@@@\n" +
                    "@@@+++%%@%%+++@@@@@@@@@@@@@@@@@@@@@@\n" +
                    "@@@@++*@@@@@#+#@@@@@@@@@@@@@@@@@@@@@\n" +
                    "@@@@%#+%@@%++++++++++**@@@@@@@@@@@@@\n" +
                    "@@@@@##+@+===========+++*%@@@@@@@@@@\n" +
                    "@@@@@@*++#=--==========++*#@@@@@@@@@\n" +
                    "@@@@@@+*+**----======-==++**%@@@@@@@\n" +
                    "@@@@@+==*+**----==--==-===+**%@@@@@@\n" +
                    "@@@@@+===++**----==--==-==++*#@@@@@@                                                       Thank you for your support\n" +
                    "@@@@%+====++*+----=--=====+++*%@@@@@\n" +
                    "@@@@@+=====+=**----==-=====++*#@@@@@\n" +
                    "@@@@@*+==*-===+*----======+++*#@@@@@\n" +
                    "@@@@@@+====-===+#----=+===++**@@@@@@\n" +
                    "@@@@@@@*+======++%----=+++++*#@@@@@@\n" +
                    "@@@@@@@@*++=====++**====+***#@@@@@@@\n" +
                    "@@@@@@@@@%*++====+++#=+++**@@@@@@@@@\n" +
                    "@@@@@@@@@@@@**+++++++%#*#@@@*++@@@@@\n" +
                    "@@@@@@@@@@@@@@@@@@@@+=*%@@@@%*=+@@@@\n" +
                    "@@@@@@@@@@@@@@@@@@@@@%#+*%@@@#+**@@@\n" +
                    "@@@@@@@@@@@@@@@@@@@@@@@*++*%%%*+##@@\n" +
                    "@@@@@@@@@@@@@@@@@@@@@@@@%+++**++++@@\n" +
                    "@@@@@@@@@@@@@@@@@@@@@@@@@@**=++++**@\n" +
                    "@@@@@@@@@@@@@@@@@@@@@@@@@@@@*+%==#*@\n" +
                    "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#*****\n" +
                    "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%**@\n" +
                    "\n");


 */
            scanner.close();
            saveSpaceshipData(spaceship);

        } catch (SQLException e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }



    }
    //loading data
    private static Spaceship loadSpaceshipData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("spaceshipData.dat"))) {
            return (Spaceship) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: Unable to load spaceship data.");
        } catch (IOException e) {
            System.out.println("I/O error while loading spaceship data.");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found: Unable to load spaceship data.");
            e.printStackTrace();
        }
        return null;
    }
    //saving data
    private static void saveSpaceshipData(Spaceship spaceship) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("spaceshipData.dat"))) {
            oos.writeObject(spaceship);
            System.out.println("Spaceship data saved successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: Unable to save spaceship data.");
        } catch (IOException e) {
            System.out.println("I/O error while saving spaceship data.");
            e.printStackTrace();
        }
    }

    public static void queryDatabase(Connection connection, String query) {
        try (Statement stmt = connection.createStatement()) {
            ResultSet resultSet = stmt.executeQuery(query);

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Print column names
            for (int i = 1; i <= columnCount; i++) {
                System.out.print(metaData.getColumnName(i) + "\t");
            }
            System.out.println();

            // Print rows
            while (resultSet.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(resultSet.getString(i) + "\t");
                }
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}

public class DuplicateObjectNameException extends Exception {

    public DuplicateObjectNameException(String message) {
        super(message);
    }
}


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SpaceshipDatabaseHelper {

    public static void insertSpaceshipData(Connection conn, Spaceship spaceship, int spacecraftId) throws SQLException {
        String query = "INSERT INTO Spaceship (spaceship_name, spacecraft_id) VALUES (?, ?)";

        PreparedStatement stmt = conn.prepareStatement(query);

        stmt.setString(1, spaceship.spaceshipName);
        stmt.setInt(2, spacecraftId);
        stmt.executeUpdate();
        stmt.close();
    }
}

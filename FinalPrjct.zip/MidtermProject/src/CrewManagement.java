import java.sql.SQLException;

public interface CrewManagement {

    public void crewWork() throws SQLException;
    public void crewSleep() throws SQLException;
    public void promote(Crew crew) throws InvalidOperationException, SQLException;
}

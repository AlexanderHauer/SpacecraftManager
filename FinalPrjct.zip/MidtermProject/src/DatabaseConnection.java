import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // Method to get the database connection
    public static Connection getConnection() throws SQLException {
        // Database connection details
        String url = "jdbc:mysql://localhost:3306/usg_ishimura";
        String username = "root";
        String password = "ishimura";

        // Create a connection to the database
        Connection connection = DriverManager.getConnection(url, username, password);
        return connection;
    }
}

import java.io.Serial;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

public class Crew implements CrewManagement, Comparable<Crew>, Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    int rank;
    int age;
    String id;
    String job;
    String crewName;
    String status;

    private static final Random random = new Random();
    ArrayList<String> list = new ArrayList<String>();


    Crew(String name, int age, String job) {
        this.crewName = name;
        this.age = age;
        this.job = job;
        this.rank = 0;
        this.status = "standing by...";


        boolean found;
        do {
            found = false;
            int num = 100000 + random.nextInt(900000);
            this.id = Integer.toString(num);

            for (String idtest : list) {
                if (idtest.equals(id)) {
                    found = true;
                }
            }
        }while (found);

        list.add(this.id);
    }

    @Override
    public void crewWork() throws SQLException {
        status = "working...";

        Connection conn = DatabaseUtils.getConnection();
        CrewDatabaseHelper.updateCrewStatus(conn, CrewDatabaseHelper.getCrewIdByName(conn, crewName), "working...");
    }

    @Override
    public void crewSleep() throws SQLException {
        status = "sleeping...";

        Connection conn = DatabaseUtils.getConnection();
        CrewDatabaseHelper.updateCrewStatus(conn, CrewDatabaseHelper.getCrewIdByName(conn, crewName), "sleeping...");
    }

    @Override
    public void promote(Crew crew) throws InvalidOperationException, SQLException {
        if (this.rank < 5) {
            this.rank++;
            System.out.println("Crew member " + this.crewName + " promoted.");

            Connection conn = DatabaseUtils.getConnection();
            CrewDatabaseHelper.updateCrewRank(conn, CrewDatabaseHelper.getCrewIdByName(conn, crewName), rank);

        } else {
            throw new InvalidOperationException("Crew member cannot be promoted. Rank is maxed out.");
        }

    }

    @Override
    public int compareTo(Crew other) {
        if (this.rank != other.rank) {
            return Integer.compare(this.rank, other.rank);
        } else {
            return Integer.compare(this.age, other.age);
        }
    }
}

import java.sql.*;
import java.util.ArrayList;


public class CrewDatabaseHelper {

    public static void addCrewToDatabase(Connection connection, Crew crew, int spacecraftId) throws SQLException {
        String insertSQL = "INSERT INTO Crew (crew_rank, age, crew_id, job, crew_name, crew_status, spacecraft_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement insertStmt = connection.prepareStatement(insertSQL);

        insertStmt.setInt(1, crew.rank);
        insertStmt.setInt(2, crew.age);
        insertStmt.setString(3, crew.id);
        insertStmt.setString(4, crew.job);
        insertStmt.setString(5, crew.crewName);
        insertStmt.setString(6, crew.status);
        insertStmt.setInt(7, spacecraftId);

        insertStmt.executeUpdate();
        insertStmt.close();
    }

    public static String getCrewIdByName(Connection connection, String crewName) throws SQLException {
        String query = "SELECT id FROM Crew WHERE crew_name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, crewName);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("id");
                }
            }
        }
        return null;
    }


    public static void updateCrewStatus(Connection connection, String crewId, String newStatus) throws SQLException {
        String updateSQL = "UPDATE Crew SET crew_status = ? WHERE id = ?";

        try (PreparedStatement updateStmt = connection.prepareStatement(updateSQL)) {
            updateStmt.setString(1, newStatus);
            updateStmt.setString(2, crewId);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Crew status updated successfully for crew_id: " + crewId);
            } else {
                System.out.println("No crew member found with crew_id: " + crewId);
            }
        }
    }

    public static void updateCrewRank(Connection connection, String crewId, int newRank) throws SQLException {
        String updateSQL = "UPDATE Crew SET crew_rank = ? WHERE id = ?";

        try (PreparedStatement updateStmt = connection.prepareStatement(updateSQL)) {
            updateStmt.setInt(1, newRank);
            updateStmt.setString(2, crewId);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Crew rank updated successfully for crew_id: " + crewId);
            } else {
                System.out.println("No crew member found with crew_id: " + crewId);
            }
        }
    }

}


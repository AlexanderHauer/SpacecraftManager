import java.io.Serial;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class Cargo implements CargoManagement, Comparable<Cargo>, Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    String name;
    double weight;
    double volume;
    int location;

    Cargo(String name, double weight, double volume, int location) {
        this.name = name;
        this.weight = weight;
        this.volume = volume;
        this.location = location;
    }

    @Override
    public void retrieveCargo(double volume) throws SQLException {
        double temp = this.volume - volume;
        this.weight = this.weight * (temp/this.volume);
        this.volume = temp;

        Connection conn = DatabaseUtils.getConnection(); // Retrieve the connection
        CargoDatabaseHelper.updateCargoVolume(conn, CargoDatabaseHelper.getCargoIdByName(conn, name), this.volume);
        CargoDatabaseHelper.updateCargoWeight(conn, CargoDatabaseHelper.getCargoIdByName(conn, name), this.weight);
    }

    @Override
    public void moveCargo(int location) throws SQLException {

        this.location = location;

        Connection conn = DatabaseUtils.getConnection();
        CargoDatabaseHelper.updateCargoLocation(conn, CargoDatabaseHelper.getCargoIdByName(conn, name), location);
    }

    @Override
    public int compareTo(Cargo other) {
        int weightComparison = Double.compare(this.weight, other.weight);
        if (weightComparison != 0) {
            return weightComparison;
        } else {
            return Double.compare(this.volume, other.volume);
        }
    }
}

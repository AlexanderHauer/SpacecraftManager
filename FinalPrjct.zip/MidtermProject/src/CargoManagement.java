import java.sql.SQLException;

public interface CargoManagement {

    public void retrieveCargo(double volume) throws SQLException;
    public void moveCargo(int location) throws SQLException;
}

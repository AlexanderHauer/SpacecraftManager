import java.sql.*;
import java.util.ArrayList;


public class CargoDatabaseHelper {

    public static void addCargoToDatabase(Connection connection, Cargo cargo, int spacecraftId) throws SQLException {
        String insertSQL = "INSERT INTO Cargo (cargo_name, weight, volume, location, spacecraft_id) " +
                "VALUES (?, ?, ?, ?, ?)";

        PreparedStatement insertStmt = connection.prepareStatement(insertSQL);
        insertStmt.setString(1, cargo.name);
        insertStmt.setDouble(2, cargo.weight);
        insertStmt.setDouble(3, cargo.volume);
        insertStmt.setInt(4, cargo.location);
        insertStmt.setInt(5, spacecraftId);

        insertStmt.executeUpdate();
        insertStmt.close();
    }

    public static String getCargoIdByName(Connection connection, String name) throws SQLException {
        String query = "SELECT id FROM Cargo WHERE cargo_name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, name);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("id");
                }
            }
        }
        return null;
    }


    public static void updateCargoVolume(Connection connection, String cargoId, double newVolume) throws SQLException {
        String updateSQL = "UPDATE Cargo SET volume = ? WHERE id = ?";

        try (PreparedStatement updateStmt = connection.prepareStatement(updateSQL)) {
            updateStmt.setDouble(1, newVolume);
            updateStmt.setString(2, cargoId);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Cargo volume updated successfully for cargo_id: " + cargoId);
            } else {
                System.out.println("No cargo found with cargo_id: " + cargoId);
            }
        }
    }

    public static void updateCargoWeight(Connection connection, String cargoId, double newWeight) throws SQLException {
        String updateSQL = "UPDATE Cargo SET weight = ? WHERE id = ?";

        try (PreparedStatement updateStmt = connection.prepareStatement(updateSQL)) {
            updateStmt.setDouble(1, newWeight);
            updateStmt.setString(2, cargoId);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Cargo weight updated successfully for cargo_id: " + cargoId);
            } else {
                System.out.println("No cargo found with cargo_id: " + cargoId);
            }
        }
    }

    public static void updateCargoLocation(Connection connection, String cargoId, int newLocation) throws SQLException {
        String updateSQL = "UPDATE Cargo SET location = ? WHERE id = ?";

        try (PreparedStatement updateStmt = connection.prepareStatement(updateSQL)) {
            updateStmt.setDouble(1, newLocation);
            updateStmt.setString(2, cargoId);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Cargo location updated successfully for cargo_id: " + cargoId);
            } else {
                System.out.println("No cargo found with cargo_id: " + cargoId);
            }
        }
    }

}


import java.sql.Connection;

public class DatabaseUtils {
    private static Connection connection;

    public static void setConnection(Connection conn) {
        connection = conn;
    }

    public static Connection getConnection() {
        return connection;
    }

}

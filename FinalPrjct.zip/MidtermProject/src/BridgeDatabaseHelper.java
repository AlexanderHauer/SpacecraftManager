import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;


public class BridgeDatabaseHelper {

    public static void addBridgeToDatabase(Connection connection, Bridge bridge, int spacecraftId) throws SQLException {
        String insertSQL = "INSERT INTO Bridge (age, bridge_name, chief_of, bridge_id, spacecraft_id) " +
                "VALUES (?, ?, ?, ?, ?)";

        PreparedStatement insertStmt = connection.prepareStatement(insertSQL);
        insertStmt.setInt(1, bridge.age);
        insertStmt.setString(2, bridge.name);
        insertStmt.setString(3, bridge.chiefOf);
        insertStmt.setString(4, bridge.id);
        insertStmt.setInt(5, spacecraftId);

        insertStmt.executeUpdate();
        insertStmt.close();
    }

}


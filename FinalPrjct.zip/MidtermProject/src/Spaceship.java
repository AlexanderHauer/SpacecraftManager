import java.io.Serial;
import java.io.Serializable;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Spaceship implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    String spaceshipName;
    Spacecraft spacecraft;
    ArrayList<Crew> crewList;
    ArrayList<Cargo> cargoList;
    ArrayList<Bridge> bridgeList;
    ArrayList<String> IDlist;
    ArrayList<String> superIDlist;
    int id;

    Spaceship(String name, Spacecraft spacecraft, ArrayList<Crew> crewList, ArrayList<Cargo> cargoList, ArrayList<Bridge> bridgeList, ArrayList<String> IDlist, ArrayList<String> superIDlist, int id) {
        this.spaceshipName = name;
        this.spacecraft = spacecraft;
        this.crewList = crewList;
        this.cargoList = cargoList;
        this.bridgeList = bridgeList;
        this.IDlist = IDlist;
        this.superIDlist = superIDlist;
        this.id = id;
    }

    Spaceship() {}
    //---------------------------adding---------------------------------------

    public void addCrew(String name) throws SQLException {
        // Check for duplicate crew name
        for (Crew crew : crewList) {
            if (crew.crewName.equals(name)) {
                try {
                    throw new DuplicateObjectNameException("A crew member with the name '" + name + "' already exists.");
                } catch (DuplicateObjectNameException e) {
                    System.out.println(e.getMessage());
                    return;
                }
            }
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Age: ");
        int age = -1;
        while (true) {
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age > 0 && age < 100) {
                    break;
                } else {
                    System.out.println("Please enter a valid age between 1 and 99.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number for age.");
            }
        }

        System.out.println("Job: ");
        String job;
        while (true) {
            job = scanner.nextLine().trim();
            if (!job.isEmpty()) {
                break;
            } else {
                System.out.println("Job cannot be empty. Please enter a valid job.");
            }
        }

        Crew crewMember = new Crew(name, age, job);
        crewList.add(crewMember);
        System.out.println("Crew member " + name + " added.");

        IDlist.add(crewMember.id);
        System.out.println("ID created");

        Connection conn = DatabaseUtils.getConnection();
        CrewDatabaseHelper.addCrewToDatabase(conn, crewMember, 7);
    }

    public void addBridge(String name) throws SQLException {
        // Check for duplicate bridge name
        for (Bridge bridge : bridgeList) {
            if (bridge.name.equals(name)) {
                try {
                    throw new DuplicateObjectNameException("A bridge member with the name '" + name + "' already exists.");
                } catch (DuplicateObjectNameException e) {
                    System.out.println(e.getMessage());
                    return;
                }
            }
        }

        Scanner scanner = new Scanner(System.in);

        System.out.println("Age: ");
        int age = -1;
        while (true) {
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age > 0 && age < 100) {  // Assuming age should be reasonable
                    break;
                } else {
                    System.out.println("Please enter a valid age between 1 and 99.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number for age.");
            }
        }

        System.out.println("Chief of: ");
        String chiefOf;
        while (true) {
            chiefOf = scanner.nextLine().trim();
            if (!chiefOf.isEmpty()) {
                break;
            } else {
                System.out.println("Job cannot be empty. Please enter a valid job.");
            }
        }


        Bridge bridgeMember = new Bridge(name, age, chiefOf);
        bridgeList.add(bridgeMember);
        System.out.println("Bridge member " + name + " added.");

        superIDlist.add(bridgeMember.id);
        System.out.println("ID created");

        Connection conn = DatabaseUtils.getConnection();
        BridgeDatabaseHelper.addBridgeToDatabase(conn, bridgeMember, 7);
    }

    public void addCargo(String name) throws SQLException {
        // Check for duplicate cargo name
        for (Cargo cargo : cargoList) {
            if (cargo.name.equals(name)) {
                try {
                    throw new DuplicateObjectNameException("A cargo item with the name '" + name + "' already exists.");
                } catch (DuplicateObjectNameException e) {
                    System.out.println(e.getMessage());
                    return;
                }
            }
        }

        Scanner scanner = new Scanner(System.in);

        System.out.print("Weight(kg): ");
        double weight = -1;
        while (true) {
            try {
                weight = Double.parseDouble(scanner.nextLine());
                if (weight > 0) {
                    break;
                } else {
                    System.out.println("Weight must be a positive number.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a numeric weight.");
            }
        }

        System.out.print("Volume(m^3): ");
        double volume = -1;
        while (true) {
            try {
                volume = Double.parseDouble(scanner.nextLine());
                if (volume > 0) {
                    break;
                } else {
                    System.out.println("Volume must be a positive number.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a numeric volume.");
            }
        }

        System.out.print("Select location (#1->#9): ");
        int location = -1;
        while (true) {
            try {
                location = Integer.parseInt(scanner.nextLine());
                if (location >= 1 && location <= 9) {
                    break;
                } else {
                    System.out.println("Please enter a valid location number between 1 and 9.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number for location.");
            }
        }


        Cargo cargo = new Cargo(name, weight, volume, location);
        cargoList.add(cargo);
        System.out.println("Cargo " + name + " added.");

        Connection conn = DatabaseUtils.getConnection();
        CargoDatabaseHelper.addCargoToDatabase(conn, cargo, 7);
    }

    //---------------------------displaying---------------------------------------

    public void displayCargo() {
        if(cargoList.isEmpty()) {
            System.out.println("No cargo on board.");
        }
        else {
            for (Cargo cargo : cargoList) {
                System.out.println(cargo.name + " weighs " + cargo.weight + " kg and has a volume of " + cargo.volume + " m^3. It is in bay #" + cargo.location);
            }
        }
    }

    public void displayCrew() {
        if(crewList.isEmpty()) {
            System.out.println("No crew on board.");
        }
        else {
            for (Crew crew : crewList) {
                System.out.println(crew.crewName + " - Rank: " + crew.rank);
                System.out.println("They are a/an " + crew.job + " and are currently " + crew.status);
                System.out.println("Age: " + crew.age);
                System.out.println("\n");
            }
        }
    }

    public void displayBridge() {
        if(bridgeList.isEmpty()) {
            System.out.println("No bridge on board.");
        }
        else {
            for (Bridge bridge : bridgeList) {
                System.out.println(bridge.name + " is " + bridge.age + " years old, and is the chief of " + bridge.chiefOf);
                System.out.println("Status: working hard");
                System.out.println("\n");
            }
        }
    }

    public void shipInfo() {
        System.out.println("The " + spaceshipName + " is part of the " + spacecraft.shipType + " class.");
        System.out.println("It is " + spacecraft.length + "m long!");
        System.out.println("It currently has " + crewList.size() + " workers and " + bridgeList.size() + " bridge members");
    }

    //---------------------------sorting & grouping---------------------------------------

    public void sortCrewByRankAndAge() {
        Collections.sort(crewList);
    }

    public void sortCargoByWeightAndVolume() {
        Collections.sort(cargoList);
    }

    public void groupCrewByJob() {
        int numThreads = 4;
        int chunkSize = (int) Math.ceil((double) crewList.size() / numThreads);
        List<CrewThread> threads = new ArrayList<>();
        Map<String, List<Crew>> groupedByJob = new ConcurrentHashMap<>();

        for (int i = 0; i < numThreads; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, crewList.size());

            if (start < end) {
                List<Crew> chunk = crewList.subList(start, end);
                CrewThread thread = new CrewThread(chunk);
                threads.add(thread);
                thread.start();
            }
        }

        for (CrewThread thread : threads) {
            try {
                thread.join();
                thread.getResult().forEach((job, members) -> {
                    groupedByJob
                            .computeIfAbsent(job, k -> Collections.synchronizedList(new ArrayList<>()))
                            .addAll(members);
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        groupedByJob.forEach((job, members) -> {
            System.out.println("Job: " + job);
            members.forEach(crew -> System.out.println("  Crew: " + crew.crewName));
        });
    }

    public void groupCargoByLocation() {
        int numThreads = 4; // Adjust based on your system's cores or dataset size
        int chunkSize = (int) Math.ceil((double) cargoList.size() / numThreads);
        List<CargoThread> threads = new ArrayList<>();
        Map<Integer, List<Cargo>> groupedByLocation = new ConcurrentHashMap<>();

        for (int i = 0; i < numThreads; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, cargoList.size());

            if (start < end) {
                List<Cargo> chunk = cargoList.subList(start, end);
                CargoThread thread = new CargoThread(chunk);
                threads.add(thread);
                thread.start();
            }
        }

        for (CargoThread thread : threads) {
            try {
                thread.join();
                thread.getResult().forEach((location, items) -> {
                    groupedByLocation
                            .computeIfAbsent(location, k -> Collections.synchronizedList(new ArrayList<>()))
                            .addAll(items);
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        groupedByLocation.forEach((location, items) -> {
            System.out.println("Location: " + location);
            items.forEach(cargo -> System.out.println("  Cargo: " + cargo.name));
        });
    }

}


/*  old->

    public void groupCargoByLocation() {
        Map<Integer, List<Cargo>> groupedByLocation = cargoList.stream().collect(Collectors.groupingBy(cargo -> cargo.location));
        groupedByLocation.forEach((location, items) -> {
            System.out.println("Location: " + location);
            items.forEach(cargo -> System.out.println("  Cargo: " + cargo.name));
        });
    }
    public void groupCrewByJob() {
        Map<String, List<Crew>> groupedByJob = crewList.stream().collect(Collectors.groupingBy(crew -> crew.job));
        groupedByJob.forEach((job, members) -> {
            System.out.println("Job: " + job);
            members.forEach(crew -> System.out.println("  Crew: " + crew.crewName));
        });
    }
*/
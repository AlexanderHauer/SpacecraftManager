import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.sql.SQLException;

public class CrewTest {

    @Test
    void testCrewConstructor() {
        Crew crewMember = new Crew("John Doe", 30, "Engineer");
        assertNotNull(crewMember, "Crew object should not be null");
        assertEquals("John Doe", crewMember.crewName, "Crew name should be 'John Doe'");
        assertEquals(30, crewMember.age, "Crew member's age should be 30");
        assertEquals("Engineer", crewMember.job, "Crew member's job should be 'Engineer'");
        assertEquals("standing by...", crewMember.status, "Crew member's status should be 'standing by...'");
        assertNotNull(crewMember.id, "Crew member should have a valid ID");
    }

    @Test
    void testCrewComparison() {
        Crew crewMember1 = new Crew("Alice", 30, "Engineer");
        crewMember1.rank = 2;
        Crew crewMember2 = new Crew("Bob", 25, "Engineer");
        crewMember2.rank = 3;
        assertTrue(crewMember1.compareTo(crewMember2) < 0, "Crew member1 should be ranked lower than crew member2");

        Crew crewMember3 = new Crew("Charlie", 35, "Engineer");
        crewMember3.rank = 2;
        assertTrue(crewMember1.compareTo(crewMember3) < 0, "Crew member1 should be younger than crew member3");

        Crew crewMember4 = new Crew("David", 30, "Engineer");
        crewMember4.rank = 2;
        assertEquals(0, crewMember1.compareTo(crewMember4), "Crew member1 should be equal to crew member4 in rank and age");
    }
}

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CargoTest {

    private Cargo cargo1;
    private Cargo cargo2;

    @BeforeEach
    public void setUp() {
        cargo1 = new Cargo("Cargo1", 100.0, 50.0, 1);
        cargo2 = new Cargo("Cargo2", 150.0, 50.0, 2);
    }

    @Test
    public void testConstructor() {
        assertNotNull(cargo1);
        assertEquals("Cargo1", cargo1.name);
        assertEquals(100.0, cargo1.weight);
        assertEquals(50.0, cargo1.volume);
        assertEquals(1, cargo1.location);
    }

    @Test
    public void testCompareTo_WeightComparison() {
        assertTrue(cargo2.compareTo(cargo1) > 0, "Cargo2 should be greater than Cargo1 based on weight");
    }

    @Test
    public void testCompareTo_VolumeComparison() {
        Cargo cargo3 = new Cargo("Cargo3", 100.0, 60.0, 3);
        assertTrue(cargo3.compareTo(cargo1) > 0, "Cargo3 should be greater than Cargo1 based on volume");
    }

    @Test
    public void testCompareTo_EqualCargo() {
        Cargo cargo4 = new Cargo("Cargo4", 100.0, 50.0, 4);
        assertEquals(0, cargo1.compareTo(cargo4), "Cargo1 and Cargo4 should be equal based on weight and volume");
    }
}

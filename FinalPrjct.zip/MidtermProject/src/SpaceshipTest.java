import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

class SpaceshipTest {

    private Spaceship spaceship;
    private Crew crewMember;
    private Bridge bridgeMember;
    private Cargo cargoItem;

    @BeforeEach
    void setUp() {
        spaceship = new Spaceship("USS Enterprise", new Spacecraft("Class A", 300),
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>(), 1);

        crewMember = new Crew("John Doe", 30, "Engineer");
        bridgeMember = new Bridge("Jane Smith", 35, "Captain");
        cargoItem = new Cargo("Food Supplies", 500, 50, 1);
    }


    @Test
    void testSortCrewByRankAndAge() {
        Crew crew1 = new Crew("Alice", 25, "Pilot");
        Crew crew2 = new Crew("Bob", 28, "Engineer");
        Crew crew3 = new Crew("Charlie", 22, "Scientist");

        spaceship.crewList.add(crew1);
        spaceship.crewList.add(crew2);
        spaceship.crewList.add(crew3);

        spaceship.sortCrewByRankAndAge();

        assertEquals(crew3, spaceship.crewList.get(0), "Crew member with lowest age should be first.");
        assertEquals(crew1, spaceship.crewList.get(1), "Crew member with middle age should be second.");
        assertEquals(crew2, spaceship.crewList.get(2), "Crew member with highest age should be last.");
    }

    @Test
    void testSortCargoByWeightAndVolume() {
        Cargo cargo1 = new Cargo("Metal", 1000, 200, 1);
        Cargo cargo2 = new Cargo("Water", 500, 100, 2);
        Cargo cargo3 = new Cargo("Food", 800, 150, 3);

        spaceship.cargoList.add(cargo1);
        spaceship.cargoList.add(cargo2);
        spaceship.cargoList.add(cargo3);

        spaceship.sortCargoByWeightAndVolume();

        assertEquals(cargo2, spaceship.cargoList.get(0), "Cargo with least weight should be first.");
        assertEquals(cargo3, spaceship.cargoList.get(1), "Cargo with middle weight should be second.");
        assertEquals(cargo1, spaceship.cargoList.get(2), "Cargo with highest weight should be last.");
    }

    @Test
    void testGroupCrewByJob() {
        Crew crew1 = new Crew("Alice", 25, "Pilot");
        Crew crew2 = new Crew("Bob", 28, "Engineer");
        Crew crew3 = new Crew("Charlie", 22, "Pilot");

        spaceship.crewList.add(crew1);
        spaceship.crewList.add(crew2);
        spaceship.crewList.add(crew3);


        spaceship.groupCrewByJob();

    }

    @Test
    void testGroupCargoByLocation() {
        Cargo cargo1 = new Cargo("Metal", 1000, 200, 1);
        Cargo cargo2 = new Cargo("Water", 500, 100, 2);
        Cargo cargo3 = new Cargo("Food", 800, 150, 1);

        spaceship.cargoList.add(cargo1);
        spaceship.cargoList.add(cargo2);
        spaceship.cargoList.add(cargo3);

        spaceship.groupCargoByLocation();

    }
}

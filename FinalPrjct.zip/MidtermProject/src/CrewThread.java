import java.util.*;

class CrewThread extends Thread {
    private final List<Crew> crewChunk;
    private final Map<String, List<Crew>> localGroupedByJob;

    public CrewThread(List<Crew> crewChunk) {
        this.crewChunk = crewChunk;
        this.localGroupedByJob = new HashMap<>();
    }

    @Override
    public void run() {
        for (Crew crew : crewChunk) {
            localGroupedByJob
                    .computeIfAbsent(crew.job, k -> new ArrayList<>())
                    .add(crew);
        }
    }

    public Map<String, List<Crew>> getResult() {
        return localGroupedByJob;
    }
}

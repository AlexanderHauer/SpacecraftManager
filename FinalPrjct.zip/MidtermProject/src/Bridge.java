import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Bridge implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    int age;
    String name;
    String chiefOf;
    String id;

    private static final Random random = new Random();
    ArrayList<String> list = new ArrayList<String>();


    Bridge(String name, int age, String chiefOf) {
        this.name = name;
        this.age = age;
        this.chiefOf = chiefOf;

        boolean found;
        do {
            found = false;
            int num = 100000 + random.nextInt(900000);
            this.id = Integer.toString(num);

            for (String idtest : list) {
                if (idtest.equals(id)) {
                    found = true;
                }
            }
        }while (found);

        list.add(this.id);
    }
}
